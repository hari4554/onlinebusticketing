package com.virtusa.model;

public class Service {
	private long serviceNo;
	private String source;
	private String destination;
	private String busType;
	private long distance;
	private String departureTime;
	private int journeyTime;
	private double fare;
	
	
	public Service() {
		super();
	}

	public long getServiceNo() {
		return serviceNo;
	}
	public void setServiceNo(long serviceNo) {
		this.serviceNo = serviceNo;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public long getDistance() {
		return distance;
	}
	public void setDistance(long distance) {
		this.distance = distance;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public int getJourneyTime() {
		return journeyTime;
	}
	public void setJourneyTime(int journeyTime) {
		this.journeyTime = journeyTime;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	
	@Override
	public String toString() {
		return "Service [serviceNo=" + serviceNo + ", source=" + source + ", destination=" + destination + ", busType="
				+ busType + ", distance=" + distance + ", departureTime=" + departureTime + ", journeyTime="
				+ journeyTime + ", fare=" + fare + " ]";
	}
	
	
}
