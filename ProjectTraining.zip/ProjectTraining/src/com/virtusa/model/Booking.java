package com.virtusa.model;

public class Booking {
	private Long bookingId;
	private Long pnrNo;
	private String journeyDate;
	private String bookingDate;
	private Long serviceNo;
	private String passengerId;
	private int noOfSeats;
	public Booking(Long bookingId, Long pnrNo, String journeyDate, String bookingDate, Long serviceNo,
			String passengerId, int noOfSeats) {
		super();
		this.bookingId = bookingId;
		this.pnrNo = pnrNo;
		this.journeyDate = journeyDate;
		this.bookingDate = bookingDate;
		this.serviceNo = serviceNo;
		this.passengerId = passengerId;
		this.noOfSeats = noOfSeats;
	}
	public Booking() {
		super();
	}
	public Long getBookingId() {
		return bookingId;
	}
	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}
	public Long getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(Long pnrNo) {
		this.pnrNo = pnrNo;
	}
	public String getJourneyDate() {
		return journeyDate;
	}
	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public Long getServiceNo() {
		return serviceNo;
	}
	public void setServiceNo(Long serviceNo) {
		this.serviceNo = serviceNo;
	}
	public String getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(String passengerId) {
		this.passengerId = passengerId;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	
}
