package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet("/ViewServiceServlet")
public class ViewServiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ViewServiceServlet() {
        super();
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	 {  
		response.setContentType("text/html"); 
		
	  
		
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");  
		PreparedStatement ps = null;
		Connection connection = null;
		try 
        {  
			PrintWriter out = response.getWriter();
    		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
   		
   		 connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
    		String sql = "select * from service where source = ? and destination = ?";
    		HttpSession session=request.getSession(false);  
    		String userName =(String)session.getAttribute("username");  
	        out.println(" <div style=\"position: absolute; top: 0; right: 0; width: 100px; text-align:right;\">\r\n"
					+ "    Hii ..\r\n"+ userName
					+ "  </div>");
   		
   		ps = connection.prepareStatement(sql);
   		ps.setString(1, source);
   		ps.setString(2, destination);
   		ResultSet rs = ps.executeQuery();
       
    		out.print("<table width=50% border=1>");  
    		out.print("<caption>Result:</caption>");  
    	
    		
    		/* Printing column names */  
    		ResultSetMetaData rsmd=rs.getMetaData();  
    		int total=rsmd.getColumnCount();  
    		out.print("<tr>");  
    		for(int i=1;i<=total;i++)  
    		{  
    		out.print("<th>"+rsmd.getColumnName(i)+"</th>");  
    		}  
    		out.print("</tr>");  
            
    		/* Printing result */  
    		  
    		while(rs.next())  
    		{  
    			final String td = "</td><td>";
        		out.print("<tr><td>"+rs.getLong(1)+td+rs.getString(2)+td+rs.getString(3)+td+rs.getString(4)+td+rs.getLong(5)+td+rs.getString(6)+td+rs.getInt(7)+td+rs.getDouble(8)+"</td></tr>");  
    		}  
    		out.print("</table>"); 
    		
    		
    		out.println("<html>");
    		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
    				+ "");
    		out.println("<body>");
    
    		out.println("<a href=BookTicket.jsp> <button>Book</button> </a> ");
    
            out.println("</body>");
            out.println("<html>");
    		
            
        }catch (Exception e2) {e2.printStackTrace();}  
                  
		finally {
			
			try {
				if(ps!=null) {
				ps.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}					
	try {
		if(connection!= null) {
		connection.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		}
        }
}