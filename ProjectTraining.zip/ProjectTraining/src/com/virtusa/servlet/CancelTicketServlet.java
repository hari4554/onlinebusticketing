package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ct")
public class CancelTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CancelTicketServlet() {
        super();
    }


	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Connection connection = null;
		PreparedStatement ps1 = null;
		try {
			PrintWriter out = res.getWriter();
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
	
			 connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
           
			HttpSession session=req.getSession(false);  
			
	        String userName =(String)session.getAttribute("username");  
	        out.println(" <div style=\"position: absolute; top: 0; right: 0; width: 100px; text-align:right;\">\r\n"
					+ "    Hii ..\r\n"+ userName
					+ "  </div>");
			

		 ps1 =connection.prepareStatement("update booking set noOfSeats= noOfSeats- ? where bookingId = ?");

		ps1.setInt(1,Integer.valueOf(req.getParameter("cancelseats")));
		ps1.setLong(2,Long.parseLong(req.getParameter("bookingId")));
		ps1.executeUpdate();
		
        

		out.println("<html>");
		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
				+ "");
		out.println("<body>");
		out.println("<h>Refund Will be Credited To Your Account In 7-8 Working Days</h>");
		out.println("<a href = Category.jsp><button><h>Logout</h></button></h>" );
        out.println("</body>");
        out.println("<html>");
		}
		catch (Exception e) { 
            e.printStackTrace(); 
        }	
		finally {
			
			try {
				if(ps1!=null) {
				ps1.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}					
	try {
		if(connection!= null) {
		connection.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
}
		
		}	
	}