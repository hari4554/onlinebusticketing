package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public RegisterServlet() {
        super();
    }
    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			String password1 = req.getParameter("password1");
			String password2 = req.getParameter("password2");
			Connection connection = null;
			PreparedStatement ps = null;
			if(password1.equals(password2)) {

				try {
					DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
					
					connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
		           

					ps=connection.prepareStatement("insert into register (username,password1,password2,name,mobilenumber,email) values(?,?,?,?,?,?)");
					
					
					ps.setString(1, req.getParameter("userName"));
					ps.setString(2, req.getParameter("password1"));
					ps.setString(3, req.getParameter("password2"));
					ps.setString(4, req.getParameter("name"));
					ps.setLong(5, Long.parseLong(req.getParameter("mobileNumber")));
					ps.setString(6, req.getParameter("email"));
					
					

				
				ps.executeUpdate();
			

		        
				PrintWriter out = res.getWriter();
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<h>...Succesfully Registered...</h>");
				out.println("<h1> Please Login To Your Account </h1>");
				out.println("<a href=Login.jsp> <button>Login</button> </a>");
		        out.println("</body>");
		        out.println("</html>");
				}
				catch (Exception e) { 
		            e.printStackTrace(); 
		        }
				finally {
					
					try {
						if(ps!=null) {
						ps.close();
						}
					} catch (Exception e1) {
						e1.printStackTrace();
					}					
			try {
				if(connection!= null) {
				connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
	}
			else {
				try {
				PrintWriter out = res.getWriter();
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<h>...The Password Doesnot Match...</h>");
				out.println("<h1> Please Register Again </h1>");
				out.println("<a href=Register.html> <button>Register</button> </a>");
		        out.println("</body>");
		        out.println("</html>");
			}catch (Exception e) {
				e.printStackTrace();
			}
			}

	}
	

	}


