package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/fs")
public class FeedbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public FeedbackServlet() {
        super();
    }
    @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	Connection connection = null;
    	PreparedStatement ps = null;

				try {
					PrintWriter out = res.getWriter();		

					HttpSession session=req.getSession(false);  
						
			        String userName =(String)session.getAttribute("username");  
			        out.println(" <div style=\"position: absolute; top: 0; right: 0; width: 100px; text-align:right;\">\r\n"
							+ "    Hii ..\r\n"+ userName
							+ "  </div>");
					
					DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
					
					 connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
		           

					 ps=connection.prepareStatement("insert into Feedback (feedbackId,name,emailId,comments) values(id_seq.nextval,?,?,?)");
					
					
					ps.setString(1, req.getParameter("name"));
					ps.setString(2, req.getParameter("emailId"));
					ps.setString(3, req.getParameter("comments"));
					

				
				ps.executeUpdate();
				

		        
				
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<h>Thanks For The Feedback</h>");
				out.println("<a href=Category.jsp> <button>Logout</button> </a>");
		        out.println("</body>");
		        out.println("<html>");
				}
				catch (Exception e) { 
		            e.printStackTrace(); 
		        } 
				finally {
					
					try {
						if(ps!=null) {
						ps.close();
						}
					} catch (Exception e1) {
						e1.printStackTrace();
					}					
			try {
				if(connection!= null) {
				connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
				}
			



	}


