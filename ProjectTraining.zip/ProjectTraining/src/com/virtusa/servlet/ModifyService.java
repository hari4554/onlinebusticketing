package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ms")
public class ModifyService extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { 
	Connection connection = null;
	PreparedStatement ps = null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		
		
		
		
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
	
			ps=connection.prepareStatement("update service set source=?,destination=?,bustype = ?,distance = ?,departuretime = ?,journeytime = ?,fare = ? where serviceno = ?");
			 
		
			 
		ps.setString(1,req.getParameter("source"));
		ps.setString(2, req.getParameter("destination"));
		ps.setString(3, req.getParameter("busType"));
		ps.setLong(4, Long.parseLong(req.getParameter("distance")));
		ps.setString(5,req.getParameter("departureTime"));
		ps.setInt(6,Integer.valueOf(req.getParameter("journeyTime")));
		ps.setDouble(7,Double.parseDouble(req.getParameter("fare")));
	
		ps.setLong(8, Long.parseLong(req.getParameter("serviceNo")));
		ps.executeUpdate();
		
			 
		
			
	
		
		PrintWriter out = res.getWriter();
		out.println("<html>");
		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
				+ "");
		out.println("<body>");
		out.println("<h style=\"background-color:powderblue;\">Successfully Modified</h>");
		out.println("<a href=ModifyService.jspl> <button>Modify Service Again</button> </a>\r\n");
		out.println("<a href=Category.jsp> <button>Logout</button> </a>");
        out.println("</body>");
        out.println("<html>");
		}
		
	catch (Exception e) {
		e.printStackTrace();
	}
		 
		finally {
			
			try {
				if(ps!=null) {
				ps.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}					
	try {
		if(connection!= null) {
		connection.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
}
		}
	

}
