package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/PrintTicket")
public class PrintTicket extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PrintTicket() {
        super();
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
		Connection connection = null;
		PreparedStatement ps = null;

        try 
        {  
    		PrintWriter out = response.getWriter();  

    		DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
    		
    		connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
    
    		String sql = "select bookingId,pnrNo,journeyDate,bookingDate,noOfSeats,service.serviceNo,source,destination,busType,departureTime,journeyTime,noOfSeats*fare as Total_Fare  from booking,service where booking.serviceNo = service.serviceNo and bookingId = ?";
    		String bookingId = request.getParameter("bookingId");
    		ps = connection.prepareStatement(sql);
    		ps.setString(1, bookingId);
    		ResultSet rs = ps.executeQuery();
    		out.print("<table width=50% border=1>");  
    		out.print("<caption>Ticket Details:</caption>");  
    	
    		
    	
    		ResultSetMetaData rsmd=rs.getMetaData();  
    		int total=rsmd.getColumnCount();  
    		out.print("<tr>");  
    		for(int i=1;i<=total;i++)  
    		{  
    		out.print("<td>"+rsmd.getColumnName(i)+"</td>");  
    		}  
    		out.print("</tr>");  
            
    		/* Printing result */  
    		  
    		while(rs.next())  
    		{  
    			final String td = "</td><td>";
    		out.print("<tr><td>"+rs.getLong(1)+td+rs.getLong(2)+td+rs.getString(3)+td+rs.getString(4)+td+rs.getInt(5)+td+rs.getLong(6)+td+rs.getString(7)+td+rs.getString(8)+td+rs.getString(9)+td+rs.getString(10)+td+rs.getInt(11)+td+rs.getDouble(12)+"</td></tr>");  
    		}  
    		out.print("</table>"); 
    		
    		connection.close();
    		out.println("<html>");
    		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
    				+ "");
    		out.println("<body>");
    		
    		out.println("<a href=Category.jsp> <button>Logout</button> </a> ");
    
            out.println("</body>");
            out.println("<html>");
    		
            
        }catch (Exception e2) {e2.printStackTrace();}  
                  
    	finally {
			
			try {
				if(ps!=null) {
				ps.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}					
	try {
		if(connection!= null) {
		connection.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
}  
          
        }  

	}
