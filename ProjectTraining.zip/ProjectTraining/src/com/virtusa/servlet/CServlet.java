package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.database.UserLoginDataBase;
import com.virtusa.model.User;


@WebServlet("/CServlet")
public class CServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CServlet() {
        super();
    }

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection connection = null;
		PreparedStatement ps1 = null;
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		String password = request.getParameter("password");
		UserLoginDataBase uld = new UserLoginDataBase();

		
		try {
HttpSession session=request.getSession(false);  
			
	        String userName =(String)session.getAttribute("username"); 
			User user = uld.checkLogin(userName, password);
			PrintWriter out = response.getWriter();
			if(user!=null) {
			if(password1.equals(password2)) {
			
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
	
			 connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
           
			 
	        out.println(" <div style=\"position: absolute; top: 0; right: 0; width: 100px; text-align:right;\">\r\n"
					+ "    Hii ..\r\n"+ userName
					+ "  </div>");
			

		 ps1 =connection.prepareStatement("update register set password1 =?, password2 = ? where password1 = ? and username = ? ");

		
		ps1.setString(1,password1);
		ps1.setString(2,password2);
		ps1.setString(3,password);
		ps1.setString(4,userName);
		ps1.executeUpdate();
		
        

		out.println("<html>");
		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
				+ "");
		out.println("<body>");
		out.println("<h>***Your Password Has Been Changed***</h>");
		out.println("<a href=Category.jsp> <button>Logout</button> </a> ");
		out.println("</body>");
        out.println("</html>");
        
		
		
		}
		else {
			
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<h>...The Password Doesnot Match...</h>");
				out.println("<h1> Please Change Again</h1>");
				out.println("<a href=ChangePassword.jsp> <button>Change Password</button> </a>");
		        out.println("</body>");
		        out.println("</html>");
			
			}
			}
			else {
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<h>...The Old Password Entered Was Incorrect...</h>");
				out.println("<h1> Please Enter The Right One</h1>");
				out.println("<a href=ChangePassword.jsp> <button>Change Password</button> </a>");
		        out.println("</body>");
		        out.println("</html>");
			}
		}
		catch (Exception e) { 
            e.printStackTrace(); 
        }	
		finally {
			
			try {
				if(ps1!=null) {
				ps1.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}					
	try {
		if(connection!= null) {
		connection.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
}
		
		}	
		
	}


