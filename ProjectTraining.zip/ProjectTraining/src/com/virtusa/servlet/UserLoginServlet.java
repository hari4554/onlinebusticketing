package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.database.UserLoginDataBase;
import com.virtusa.model.User;

@WebServlet("/LoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UserLoginServlet() {
        super();
    }
    @Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		UserLoginDataBase uldb = new UserLoginDataBase();
		try {
			User user = uldb.checkLogin(userName, password);
                if(user != null){
        			PrintWriter out = response.getWriter();
        			HttpSession session=request.getSession();  
        	        session.setAttribute("username",userName);  
                	out.println("<html>");
                	out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
            				+ "");
        			out.println("<body>");
        			out.println("<p>Log in Successful</p>");
        			out.println(" <div style=\"position: absolute; top: 0; right: 0; width: 100px; text-align:right;\">\r\n"
        					+ "    Hii ..\r\n"+ userName
        					+ "  </div>");
        			
        			
        			out.println("<a href=ViewService.jsp> <button>Book Service</button> </a>");
        			out.println("<a href=CancelTicket.jsp> <button>Cancel Ticket</button></a>");
        			out.println("<a href=PrintTicket.jsp> <button>Print Ticket</button></a>");
        			out.println("<a href=Feedback.jsp> <button>Feedback</button> </a>");
        			out.println("<a href=ChangePassword.jsp> <button>Change Password</button> </a>");
        			out.println("<a href=Login.jsp> <button>Logout</button> </a>");

        	        out.println("</body>");
        	        out.println("</html>");
                }
                else {
                	PrintWriter out = response.getWriter();
        			out.println("<html>");
        			out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
            				+ "");
        			out.println("<body>");
        			out.println("<p>Credentials are Incorrect</p>");
        	        out.println("</body>");
        	        out.println("</html>");
        	        RequestDispatcher rd = request.getRequestDispatcher("Category.jsp");
        			rd.include(request, response);
                }
              
        		
               
				
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	
           
            
	}
}


