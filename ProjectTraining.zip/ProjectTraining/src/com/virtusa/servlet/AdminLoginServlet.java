package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.database.AdminLoginDataBase;
import com.virtusa.model.Admin;


@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public AdminLoginServlet() {
        super();
    }

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		AdminLoginDataBase aldb = new AdminLoginDataBase();
	try {
		Admin admin = aldb.checkLogin(userName, password);
		PrintWriter out = response.getWriter();
	
		if(admin != null) {
				
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<p>Log in Successful</p>");
				out.println("<a href=AddService.jsp> <button>Add Service</button> </a>");
				out.println("<a href=serviceno.jsp> <button>Modify Service</button></a>");
				out.println("<a href=DeleteService.jsp> <button>Delete Service</button></a>");
				out.println("<a href=fedback.jsp> <button>View Feedback</button></a>");
				out.println("<a href=Category.jsp> <button>Logout</button> </a>");

		        out.println("</body>");
		        out.println("</html>");
			}
		 else {

 			out.println("<html>");
 			out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
    				+ "");
 			out.println("<body>");
 			out.println("<p>Credentials are Incorrect</p>");
 	        out.println("</body>");
 	        out.println("</html>");
 	        RequestDispatcher rd = request.getRequestDispatcher("Category.jsp");
 			rd.include(request, response);
		 }
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	}

}
