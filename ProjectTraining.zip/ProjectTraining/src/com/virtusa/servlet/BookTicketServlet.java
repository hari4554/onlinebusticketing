package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.database.SeatsDataBase;



@WebServlet("/bt")
public class BookTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public BookTicketServlet() {
        super();
    }
    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    	SeatsDataBase sdb = new SeatsDataBase();
    	Connection connection = null;
    	PreparedStatement ps = null;
    	PreparedStatement ps1 =null;
    	
    	try {
    		String jDate = req.getParameter("journeyDate");
        	String bDate = req.getParameter("bookingDate");
        	Long sNo =  Long.parseLong(req.getParameter("serviceNo"));
        	int seats = Integer.parseInt(req.getParameter("seats"));
        	PrintWriter out = res.getWriter();
    		int a = sdb.checkSeats(sNo);
			if(a<30) {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		
			
			
		
			connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
			HttpSession session=req.getSession(false);  
			
	        String userName =(String)session.getAttribute("username");  
	        out.println(" <div style=\"position: absolute; top: 0; right: 0; width: 100px; text-align:right;\">\r\n"
					+ "    Hii ..\r\n"+ userName
					+ "  </div>");
			
	        ps=connection.prepareStatement("insert into Booking values(bid_seq.nextval,pnr_seq.nextval,?,?,?,?,?)");
			ps.setString(1, jDate);
			ps.setString(2, bDate);
			ps.setLong(3, sNo);
			ps.setString(4, userName);		
			ps.setInt(5,seats);
			ps.executeUpdate();
			ps1 = connection.prepareStatement("select bookingId,noOfSeats*fare as totalfare from booking,service where booking.serviceNo = service.serviceNo and journeyDate =? and bookingDate = ? and service.serviceNo=? and passengerId=? and noOfSeats=?");
			ps1.setString(1, jDate);
			ps1.setString(2, bDate);
			ps1.setLong(3, sNo);
			ps1.setString(4, userName);		
			ps1.setInt(5,seats);
			ResultSet rs = ps1.executeQuery();
			while(rs.next()) {
				Long bId = rs.getLong(1);
				Double tfare = rs.getDouble(2);
		out.println("<html>");
		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
				+ "");
		out.println("<body>");
		out.println("<h>Booking Id is </h>"+ bId);
		out.println("<a href = Payment.jsp><button><h>Pay amount</h></button></h>"+ tfare );
        out.println("</body>");
        out.println("</html>");
			}
			
	
			}
			else {
				out.println("<html>");
				out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
	    				+ "");
				out.println("<body>");
				out.println("<h>All The Seats Have Been Booked For This Service...</h>");
				out.println("<h>Please Go For Other Service...</h>");
				out.println("<a href = Category.jsp><button><h>Logout</h></button></h>" );
		        out.println("</body>");
		        out.println("</html>");
			}
		}
		
		catch (Exception e) { 
            e.printStackTrace(); 
        }
    	finally {
			
			try {
				if(ps!=null) {
				ps.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			try {
				if(ps1!=null) {
				ps1.close();
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}		
	try {
		if(connection!= null) {
		connection.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		
		}
		
		}
}
	

