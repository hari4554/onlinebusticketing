package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.database.ServiceNoDataBase;
import com.virtusa.model.Service;

@WebServlet("/DeleteServiceServlet")
public class DeleteServiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public DeleteServiceServlet() {
        super();
    }
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServiceNoDataBase sndb = new ServiceNoDataBase();
  		Service service;
  		Connection connection = null;
  		PreparedStatement ps = null;
  		PreparedStatement ps1 = null;
			try {
				Long serviceNo = Long.parseLong(request.getParameter("serviceno"));

				service = sndb.checkService(serviceNo);
				PrintWriter out = response.getWriter();	
			if(service!= null) {
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		
		
		
		
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
	
		 ps=connection.prepareStatement("delete from booking where serviceNo = ?");
		 
		
			 
		ps.setLong(1,serviceNo);
		
		ps.executeUpdate();
	
		ps1=connection.prepareStatement("delete from service where serviceNo = ?");
		  
		  
		  
		  ps1.setLong(1,serviceNo);
		  
		  ps1.executeUpdate();
		 
	
		out.println("<html>");
		out.println("<body>");
	
	out.println("<h style=\"background-color:powderblue;\">*** Successfully Deleted ***</h>");
		
		out.println("<a href=Category.jsp> <button>Logout</button> </a>");
		out.println("</body>");
        out.println("</html>");
		 }
			else {
     			out.println("<html>");
     			out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
        				+ "");
     			out.println("<body>");
     			out.println("<p>Service Number Not Found</p>");
     	        out.println("</body>");
     	        out.println("</html>");
     	        RequestDispatcher rd = request.getRequestDispatcher("DeleteService.jsp");
     			rd.include(request, response);
             }
			}
	catch (Exception e) {
		e.printStackTrace();
	}
			finally {
				
				try {
					if(ps!=null) {
					ps.close();
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				try {
					if(ps1!=null) {
					ps1.close();
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}		
		try {
			if(connection!= null) {
			connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	}
}