package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/kk")
public class AddServiceServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException { 
		
		Connection connection = null;
		PreparedStatement ps = null;	
			try {
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
					
			
		 connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");

			 ps=connection.prepareStatement("insert into service values(?,?,?,?,?,?,?,?)");

		ps.setLong(1, Long.parseLong(req.getParameter("serviceNo")));
		ps.setString(2,req.getParameter("source"));
		ps.setString(3, req.getParameter("destination"));
		ps.setString(4, req.getParameter("busType"));
		ps.setLong(5, Long.parseLong(req.getParameter("distance")));
		ps.setString(6,req.getParameter("departureTime"));
		ps.setInt(7,Integer.parseInt(req.getParameter("journeyTime")));
		ps.setDouble(8,Double.parseDouble(req.getParameter("fare")));

		
		ps.executeUpdate();
			}
			catch (Exception e) {
				e.printStackTrace();
			}

			finally {
				
					try {
						if(ps!=null) {
						ps.close();
						}
					} catch (Exception e1) {
						e1.printStackTrace();
					}					
			try {
				if(connection!= null) {
				connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
			try {
		PrintWriter out = res.getWriter();
		out.println("<html>");
		out.println("<link rel=\"stylesheet\" href=\"design.css\">\r\n"
				+ "");
		out.println("<body>");
		out.println("<h>Successfully Added</h>");
		out.println("<a href=AddService.jsp> <button>Add Service Again</button> </a>\r\n");
		out.println("<a href=Category.jsp> <button>Logout</button> </a>");

        out.println("</body>");
        out.println("<html>");
		}
			catch(Exception e){
				e.printStackTrace();
			}
	}
		
	
        	
	}
	



