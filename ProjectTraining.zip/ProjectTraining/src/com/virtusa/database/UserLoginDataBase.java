package com.virtusa.database;
 
import java.sql.*;

import com.virtusa.model.User;
 
public class UserLoginDataBase {
	Connection connection = null;
	PreparedStatement statement = null;
	 User user = null;
    public User checkLogin(String userName, String password1) throws SQLException
             {
    	try {
    	DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
        String sql = "SELECT * FROM register WHERE username = ? and password1 = ?";
         statement = connection.prepareStatement(sql);
        statement.setString(1, userName);
        statement.setString(2, password1);
 
        ResultSet result = statement.executeQuery();
 
       
 
        if (result.next()) {
            user = new User();
            user.setUsername(userName);
            user.setPassword1(password1);
        }
    	}catch (Exception e) {
			e.printStackTrace();
		}
        finally {
    		try {
				if(connection!= null) {
				connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
    		try {
				if(statement!= null) {
				statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}

        return user;
    }
}