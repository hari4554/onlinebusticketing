package com.virtusa.database;
 
import java.sql.*;

import com.virtusa.model.Admin;

 
public class AdminLoginDataBase {
	Connection connection = null;
	PreparedStatement statement = null;
	 Admin admin = null;
    public Admin checkLogin(String userName, String password) throws SQLException
             {
    	try {
    	DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
        String sql = "SELECT * FROM admin WHERE username = ? and password = ?";
         statement = connection.prepareStatement(sql);
        statement.setString(1, userName);
        statement.setString(2, password);
 
        ResultSet result = statement.executeQuery();
 
       
 
        if (result.next()) {
            admin = new Admin();
            admin.setUsername(userName);
            admin.setPassword(password);
        }
    	}catch (Exception e) {
			e.printStackTrace();
		}
        finally {
    		try {
				if(connection!= null) {
				connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
    		try {
				if(statement!= null) {
				statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}

        return admin;
    }
}