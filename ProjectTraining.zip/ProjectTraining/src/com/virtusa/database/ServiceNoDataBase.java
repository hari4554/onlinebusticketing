package com.virtusa.database;
 
import java.sql.*;

import com.virtusa.model.Service;

 
public class ServiceNoDataBase {
	Connection connection = null;
	Service service = null;
	PreparedStatement statement = null;
    public Service checkService(Long serviceNo) throws SQLException {
    	
    	try {
    	DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
		 connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","hari");
        String sql = "SELECT * FROM service WHERE serviceNo = ?";
        statement = connection.prepareStatement(sql);
        statement.setLong(1, serviceNo);
   
 
        ResultSet result = statement.executeQuery();
 
        
 
        if (result.next()) {
            service = new Service();
            service.setServiceNo(serviceNo);
            
        }
    	}
    
    	catch (Exception e) {
			e.printStackTrace();
		}
    
    	finally {
    		try {
				if(connection!= null) {
				connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
    		try {
				if(statement!= null) {
				statement.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}
		return service;
		

		
    	}
}
